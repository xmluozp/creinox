export const _DATATYPES = {
    INT: "INT",
    VARCHAR: "VARCHAR",
    DATETIME: "DATETIME",
    TEXT: "TEXT",
    BOOLEAN: "BOOLEAN",
    SELECT: "SELECT",
}